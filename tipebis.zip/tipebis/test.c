#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h> 
#include<time.h>  
#include<string.h>
 
#include "donnees.h"

int main(){
	//notre pb
	int j;
	printf("Nombre de jours (multiple de 4): ");
	int res=scanf("%d",&j);
	time_t begin=time (NULL);
	tab_tab remp_aut=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_aut,"demande_tab_aut.csv");
	tab_tab remp_hiv=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_hiv,"demande_tab_hiv.csv");
	tab_tab remp_prin=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_prin,"demande_tab_prin.csv");
	tab_tab remp_ete=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_ete,"demande_tab_ete.csv");
	
	grandit_tab(remp_aut,j/4);
	grandit_tab(remp_hiv,j/4);
	grandit_tab(remp_prin,j/4);
	grandit_tab(remp_ete,j/4);

	
	tab_tab remp=combine_tab(remp_aut,remp_hiv,remp_prin,remp_ete,j/4);

	float Enom= 100; 
	float SOCstart=0 ;
	float SOCmin= 0 ;
	float SOCmax= 100 ; 
	float SOCend=0 ; 

	mat mmm=entree(j*24,remp->dem,remp->prod,remp->c,remp->cp,remp->pres_min,remp->pres_max,Enom,SOCstart,SOCmin,SOCmax,SOCend) ;
	//print_matrice(mmm) ;
	mat mm2=phase1_v2(mmm) ;
	
	simplexe_min(mm2) ;
	//print_matrice(mm2) ;

	res_tab valeurs=var_res(mm2);
	print_var(valeurs,remp->prod,remp->dem);
	
	time_t end=time(NULL);
	unsigned long diff= (unsigned long) difftime (end,begin) ;
	int sec=diff%60 ;
	printf("temps : %ld min %d sec\n",diff/60,sec);
	
	float* tab=stock(24*j,valeurs.tab_ach,valeurs.tab_prod,remp->dem,Enom,SOCstart);
	float* tab2 = dPpv(24*j, valeurs.tab_ven, valeurs.tab_prod, remp->prod) ;
	float* tab3 = pst(24*j,valeurs.tab_ach,valeurs.tab_prod,remp->dem) ;
	//printf("stock\n") ;
		
	extract_var(valeurs,tab,"op_data.csv",remp->subdiv);
	if (j>15){
		float fac_tot=fact_an(valeurs,remp->c,remp->cp,j,4);
		printf("\n fac tot %f",fac_tot);
	}
	float fac=calc_fact(j*24,valeurs,remp->c,remp->cp);
	printf("\n %f",fac);
	libere_tab(remp);

	remp_aut=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_aut,"demande_tab_aut_bis.csv");
	remp_hiv=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_hiv,"demande_tab_hiv_bis.csv");
	remp_prin=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_prin,"demande_tab_prin_bis.csv");
	remp_ete=malloc(sizeof(struct tabdonnees));
	recup_tab(remp_ete,"demande_tab_ete_bis.csv");

    grandit_tab(remp_aut,j/4);
	grandit_tab(remp_hiv,j/4);
	grandit_tab(remp_prin,j/4);
	grandit_tab(remp_ete,j/4);
	
	remp=combine_tab(remp_aut,remp_hiv,remp_prin,remp_ete,j/4);
	
	mmm=entree(j*24,remp->dem,remp->prod,remp->c,remp->cp,remp->pres_min,remp->pres_max,Enom,SOCstart,SOCmin,SOCmax,SOCend) ;
	//print_matrice(mmm) ;
	mm2=phase1_v2(mmm) ;
	
	simplexe_min(mm2) ;
	//printres(mm2,j*24) ;
	printf("\n") ;

	valeurs=var_res(mm2);
	tab=stock(24*j,valeurs.tab_ach,valeurs.tab_prod,remp->dem,Enom,SOCstart);
	extract_var(valeurs,tab,"op_data_bis.csv",remp->subdiv);
	if (j>15){
		float fac_tot=fact_an(valeurs,remp->c,remp->cp,j,4);
		printf("\n fac tot %f",fac_tot);
	}
	fac=calc_fact(j*24,valeurs,remp->c,remp->cp);
	printf("\n %f",fac);
	printf("\n") ;
	valeurs=glouton_stockless(j*24,remp->dem,remp->prod,remp->c,remp->cp,remp->pres_min,remp->pres_max);//,Enom,SOCstart,SOCmin,SOCmax,SOCend) ;
	//print_var(valeurs,remp->prod,remp->dem);
	tab=stock(24*j,valeurs.tab_ach,valeurs.tab_prod,remp->dem,Enom,SOCstart);
	extract_var(valeurs,tab,"op_data_glouton.csv",remp->subdiv);
	if (j>15){
		float fac_tot=fact_an(valeurs,remp->c,remp->cp,j,4);
		printf("\n fac tot %f",fac_tot);
	}
	fac=calc_fact(j*24,valeurs,remp->c,remp->cp);
	printf("\n %f",fac);
			
	free(tab);
	printf("\n");	
	libere_tab(remp);
	free(tab2) ;
	free(tab3) ;
	libere_res(valeurs) ;
	libere_matrice(mm2) ;
	libere_matrice(mmm) ;
}


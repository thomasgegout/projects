#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h>  
#include<string.h>

#include "simplexe.c"

struct tabdonnees {
	float* subdiv;
	float* dem;
	float* prod;
	float* pres_min;
	float* pres_max;
	float* c;
	float* cp;
};

typedef struct tabdonnees *tab_tab;

void libere_tab (tab_tab remp){
//libère la mémoire prise par remp
	free(remp->prod);
	free(remp->dem);
	free(remp->pres_min);
	free(remp->pres_max);
	free(remp->c);
	free(remp->cp);
	free(remp->subdiv);
	free(remp);
}


void recup_tab (tab_tab remplir,char* name){
	//Modifie les tableaux selon la subdivision et les valeurs de "name"
	float* tab_d=malloc(sizeof(float)*(24));
	float* tab_p=malloc(sizeof(float)*(24));
	float* pres_min=malloc(sizeof(float)*(24));
	float* pres_max=malloc(sizeof(float)*(24));
	float* c=malloc(sizeof(float)*(24));
	float* cp=malloc(sizeof(float)*(24));
	float* tab=malloc(sizeof(float)*(24));
	FILE *file_ptr;
	file_ptr=fopen(name,"r");
	char lig[1024];
	const char* sep=",\n";	
	char* val;
	fgets(lig, 1024, file_ptr);
	for (int cpt=0; cpt<24; cpt++){
		fgets(lig, 1024, file_ptr);
		val=strtok(lig,sep);
		tab[cpt]=atof(val);
		val=strtok(NULL,sep);
		tab_d[cpt]=atof(val);
		val=strtok(NULL,sep);
		tab_p[cpt]=atof(val);
		cp[cpt]=0.10;
		if (cpt>4 && cpt<22){
			c[cpt]=0.1841;
		}
		else{
			c[cpt]=0.1470;
		}
	}
	fclose(file_ptr);
	for (int j=0; j<23; j++){
		float diff=tab[j+1]-tab[j];
		pres_min[j]=diff*(-1);
		pres_max[j]=diff*1;
		if (tab[j]<5 && tab [j+1]>=5){
			c[j]=((tab[j+1]-5)*c[j+1]+(5-tab[j])*c[j])/(tab[j+1]-tab[j]);
		}
		else if (tab[j]<22 && tab[j+1]>=22){
			c[j]=((tab[j+1]-22)*c[j+1]+(22-tab[j])*c[j])/(tab[j+1]-tab[j]);
		}
		tab_p[j]=diff*tab_p[j];
		tab_d[j]=diff*tab_d[j];
	}
	pres_min[23]=(24-tab[23])*(-1);
	pres_max[23]=(24-tab[23])*1;
	tab_p[23]=(24-tab[23])*tab_p[23];
	tab_d[23]=(24-tab[23])*tab_d[23];
	cp[23]=cp[22];
	c[23]=c[22];
	remplir->dem=tab_d;
	remplir->prod=tab_p;
	remplir->pres_min=pres_min;
	remplir->pres_max=pres_max;
	remplir->c=c;
	remplir->cp=cp;
	remplir->subdiv=tab;
}

void grandit_tab (tab_tab remp, int j){
	float* p2=(float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
	    for (int ct=0; ct<24 ; ct++){
			int saison=cpt/4;
			if (saison==0)
	       		p2[24*cpt+ct]=remp->prod[ct];
			else if (saison==1)
				p2[24*cpt+ct]=remp->prod[ct];
			else if (saison==2)
				p2[24*cpt+ct]=remp->prod[ct];
			else 
				p2[24*cpt+ct]=remp->prod[ct];
	    }
	}
	float* cp2=(float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
	    for (int ct=0; ct<24 ; ct++){
	        cp2[24*cpt+ct]=1*remp->cp[ct];
	    }
	}
	float* c2=(float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
	    for (int ct=0; ct<24 ; ct++){
	        c2[24*cpt+ct]=remp->c[ct];
	    }
	}
	float* d2=(float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
	    for (int ct=0; ct<24 ; ct++){
			int saison=cpt/4;
			if (saison==0)
	       		d2[24*cpt+ct]=remp->dem[ct];
			else if (saison==1)
				d2[24*cpt+ct]=remp->dem[ct];
			else if (saison==2)
				d2[24*cpt+ct]=remp->dem[ct];
			else 
				d2[24*cpt+ct]=remp->dem[ct];
	    }
	}
	float* pres_min2 = (float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
		for (int ct=0; ct<24 ; ct++){
	       		pres_min2[24*cpt+ct]=remp->pres_min[ct];
	    }
	}
	float* pres_max2 = (float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
		for (int ct=0; ct<24 ; ct++){
	       		pres_max2[24*cpt+ct]=remp->pres_max[ct];
	    }
	}
	float* subdiv2 = (float*) malloc(sizeof(float)*(j*24));
	for (int cpt=0; cpt<j ; cpt++){
		for (int ct=0; ct<24 ; ct++){
	       		subdiv2[24*cpt+ct]=24*cpt+remp->subdiv[ct];
	    }
	}
	free(remp->prod);
	free(remp->dem);
	free(remp->pres_min);
	free(remp->pres_max);
	free(remp->c);
	free(remp->cp);
	free(remp->subdiv);
	remp->dem=d2;
	remp->prod=p2;
	remp->pres_min=pres_min2;
	remp->pres_max=pres_max2;
	remp->c=c2;
	remp->cp=cp2;
	remp->subdiv=subdiv2;
}

tab_tab combine_tab (tab_tab aut,tab_tab hiv,tab_tab prin,tab_tab ete,int nb_j){
//Recombine les tableaux d'un an selon les saisons et leur durée (et les libère)
	tab_tab retour=malloc (sizeof(struct tabdonnees));
	float* prod=malloc (sizeof(float)*24*nb_j*4);
	float* dem=malloc (sizeof(float)*24*nb_j*4);
	float* pres_min=malloc (sizeof(float)*24*nb_j*4);
	float* pres_max=malloc (sizeof(float)*24*nb_j*4);
	float* c=malloc (sizeof(float)*24*nb_j*4);
	float* cp=malloc (sizeof(float)*24*nb_j*4);
	float* subdiv=malloc (sizeof(float)*24*nb_j*4);
	for (int i=0; i<24*nb_j; i++){
		prod[i]=aut->prod[i];
		prod[24*nb_j+i]=hiv->prod[i];
		prod[24*nb_j*2+i]=prin->prod[i];
		prod[24*nb_j*3+i]=ete->prod[i];
		dem[i]=aut->dem[i];
		dem[24*nb_j+i]=hiv->dem[i];
		dem[24*nb_j*2+i]=prin->dem[i];
		dem[24*nb_j*3+i]=ete->dem[i];
		pres_min[i]=aut->pres_min[i];
		pres_min[24*nb_j+i]=hiv->pres_min[i];
		pres_min[24*nb_j*2+i]=prin->pres_min[i];
		pres_min[24*nb_j*3+i]=ete->pres_min[i];
		pres_max[i]=aut->pres_max[i];
		pres_max[24*nb_j+i]=hiv->pres_max[i];
		pres_max[24*nb_j*2+i]=prin->pres_max[i];
		pres_max[24*nb_j*3+i]=ete->pres_max[i];
		c[i]=aut->c[i];
		c[24*nb_j+i]=hiv->c[i];
		c[24*nb_j*2+i]=prin->c[i];
		c[24*nb_j*3+i]=ete->c[i];
		cp[i]=aut->cp[i];
		cp[24*nb_j+i]=hiv->cp[i];
		cp[24*nb_j*2+i]=prin->cp[i];
		cp[24*nb_j*3+i]=ete->cp[i];
		subdiv[i]=aut->subdiv[i];
		subdiv[24*nb_j+i]=hiv->subdiv[i]+24*nb_j;
		subdiv[24*nb_j*2+i]=prin->subdiv[i]+24*nb_j+i*2;
		subdiv[24*nb_j*3+i]=ete->subdiv[i]+24*nb_j+i*3;
	}
	retour->prod=prod;
	retour->dem=dem;
	retour->pres_min=pres_min;
	retour->pres_max=pres_max;
	retour->cp=cp;
	retour->c=c;
	retour->subdiv=subdiv;
	libere_tab(aut);
	libere_tab(hiv);
	libere_tab(prin);
	libere_tab(ete);
	return retour;
}
		
		
	

float calc_fact(int h,res_tab resultats,float* c,float* cp){
//Calcule la facture sur le nombre d'heures correspondant
	float fact=0;
	for (int j=0; j<h; j++){
		fact=fact+resultats.tab_ach[j]*c[j]+resultats.tab_ven[j]*cp[j];
	}
	return fact;
}
	


void extract_var (res_tab var,float* tab,char* name,float* subdiv){
	//Ecrit dans le fichier "op_data.csv" les variables obtenues à la fin
	FILE *file_ptr;
	file_ptr=fopen(name,"w");
	fprintf(file_ptr,"h,ea,ev,stk\n");
	int i;
	for (i=0;i<var.size;i++){
		fprintf(file_ptr,"%f,%f,%f,%f\n",subdiv[i],var.tab_ach[i],var.tab_ven[i],tab[i]);
	}
	fclose(file_ptr);
}

float fact_an (res_tab var,float* pria,float* priv,int jours,int long_saison){
	//Calcule la facture résultante pour un an a partir d'une simulation sur
	//une durée de [jours] jours où les saisons durent long_saison jours
	//long_saison>=4
	float facture_gen=0;
	float fac_ete=0;
	float fac_aut=0;
	float fac_hiv=0;
	float fac_print=0;
	for (int i=0;i<48;i++){
		fac_aut=var.tab_ach[i+24*1]*pria[i+24*1]+fac_aut;
		fac_hiv=var.tab_ach[i+24*(long_saison+1)]*pria[i+24*(long_saison+1)]+fac_hiv;
		fac_print=var.tab_ach[i+24*(2*long_saison+1)]*pria[i+24*(2*long_saison+1)]+fac_print;
		fac_ete=var.tab_ach[i+24*(3*long_saison+1)]*pria[i+24*(3*long_saison+1)]+fac_ete;
		fac_aut=fac_aut-var.tab_ven[i+24*1]*priv[i+24*1];
		fac_hiv=fac_hiv-var.tab_ven[i+24*(long_saison+1)]*priv[i+24*(long_saison+1)];
		fac_print=fac_print-var.tab_ven[i+24*(2*long_saison+1)]*priv[i+24*(2*long_saison+1)];
		fac_ete=fac_ete-var.tab_ven[i+24*(3*long_saison+1)]*priv[i+24*(3*long_saison+1)];
	}
	for (int i=0;i<48;i++){
		facture_gen=facture_gen+var.tab_ach[i+(long_saison -1)*24]*pria[i+(long_saison -1)*24];
		facture_gen=facture_gen+var.tab_ach[i+(2*long_saison -1)*24]*pria[i+(2*long_saison -1)*24];
		facture_gen=facture_gen+var.tab_ach[i+(3*long_saison -1)*24]*pria[i+(3*long_saison -1)*24];
		facture_gen=facture_gen-var.tab_ven[i+(long_saison -1)*24]*priv[i+(long_saison -1)*24];
		facture_gen=facture_gen-var.tab_ven[i+(2*long_saison -1)*24]*priv[i+(2*long_saison -1)*24];
		facture_gen=facture_gen-var.tab_ven[i+(3*long_saison -1)*24]*priv[i+(3*long_saison -1)*24];
	}
	facture_gen=facture_gen+45*fac_ete;
	facture_gen=facture_gen+45*fac_aut;
	facture_gen=facture_gen+45*fac_hiv;
	facture_gen=facture_gen+45*fac_print;
	return facture_gen;
}

res_tab glouton_stockless (int nb_h,float* d,float* p,float* c,float* cp,float*pres_min,
				float* pres_max){
//Calcule le résultat glouton correspondant aux entrées sans stock
	res_tab res;
	res.size=nb_h;
	float* tab_ach=malloc(sizeof(float)*nb_h);
	float* tab_ven=malloc(sizeof(float)*nb_h); 
	float* tab_prod=malloc(sizeof(float)*nb_h);
	for (int i=0;i<nb_h;i++){
		float diff=p[i]-d[i];
		if (diff>0.00){
			tab_ach[i]=0.000;
			if (diff<pres_max[i]){
					tab_ven[i]=diff;
				}
			else {
				tab_ven[i]=pres_max[i];
				}
		}
		else {
			tab_ven[i]=0.000;
			tab_ach[i]=-diff;
		}
		tab_prod[i]=p[i]-tab_ven[i];
	}
	res.tab_ach=tab_ach;
	res.tab_ven=tab_ven;
	res.tab_prod=tab_prod;
	return res;
}

res_tab glouton (int nb_h,float* d,float* p,float* c,float* cp,float*pres_min,
				float* pres_max,float Enom,float SOCstart,
				float SOCmin,float SOCmax,float SOCend){
//Calcule le résultat glouton correspondant aux entrées 
	res_tab res;
	res.size=nb_h;
	float* tab_ach=malloc(sizeof(float)*nb_h);
	float* tab_ven=malloc(sizeof(float)*nb_h); 
	float* tab_prod=malloc(sizeof(float)*nb_h);
	float stock=SOCstart;
	for (int i=0;i<nb_h;i++){
		float d2=d[i]-stock*Enom;
		if (d2<0.0){
			d2=0.0;
		}
		float diff=p[i]-d2;
		if (diff>0.00){
			tab_ach[i]=0.000;
			if (diff<pres_max[i]){
					tab_ven[i]=diff;
				}
			else {
				tab_ven[i]=pres_max[i];
				}
		}
		else {
			tab_ven[i]=0.000;
			tab_ach[i]=-diff;
		}
		tab_prod[i]=p[i]-tab_ven[i];
		stock=stock-(100*1)/(Enom)*(d[i]-tab_prod[i]);
		if (stock>100.0) {
			stock=100.0;
		}
		else if (stock<0.0){
			stock=0.00;
		}
	}
	res.tab_ach=tab_ach;
	res.tab_ven=tab_ven;
	res.tab_prod=tab_prod;
	return res;
}

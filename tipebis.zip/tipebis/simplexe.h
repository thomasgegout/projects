#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h> 
#include<time.h> 

bool egalite(float a, float b);

struct matrice{
	int n ; //nombre de lignes
	int p ; //nombre de colonnes
	float** M ; //tableau de taille n de tableaux de taille p (contient les lignes de la matrice)
};

typedef struct matrice* mat ;

struct resultats{
	int size ; //nombre d'heures
	float* tab_ach ; //tableau de taille size des opérations d'achat
	float* tab_ven ; //tableau de taille size des opérations de vente
	float* tab_prod; //tableau de taille size des opérations p3
};

typedef struct resultats res_tab ;

mat cree_matrice(int n , int p);

void libere_matrice(mat m);
	
void print_matrice(mat m);

void printres(mat m, int n);

void multiplie(mat m, int l, float k);

void ajoute(mat m, int l, float k, int ll);

void echange(mat m, int l, int ll);

void pivot_gauss(mat m, int pl, int pc);

int pivot_colonne_min(float* tab, int n);

int pivot_colonne_max(float* tab, int n);

int pivot_ligne(mat m, int pc);

void simplexe_min(mat m); 

void simplexe_max(mat m);

mat construit_entree(int n, float* p, float* d, float* c, float* cp, float C, float s, float f);

mat entree(int n, float* pconso, float* pprod, float* ca, float* cv, float* pres_min, float* pres_max, float Enom, float SOCstart, float SOCmin, float SOCmax, float SOCend) ;

mat construit_entree_dim(int n, float* ea, float* ev, float* p, float* d, float cs, float cc, float smax, float cmax, float s) ; 

mat phase1_v2(mat mmm);

res_tab var_res (mat m);

void print_var (res_tab rtb,float* p,float* d);

void libere_res (res_tab rtb);

float* stock(int n, float* ea, float* p3, float* d, float C, float s);

float* dPpv(int n, float* ev, float* p3, float* p);

float* pst(int n, float* ea, float* p3, float* d);

# Créé par Tom, le 18/01/2023 en Python 3.7
import csv
import matplotlib.pyplot as plt
import numpy as np
import math

xexp=[]
yexp=[]
x=[]
y=[]

portee=52.2
seuil=37
pepite=0.00

xmax=1.5
nb_pts=100
yy=0
xx=0

for i in range(nb_pts):
	x.append(xx)
	y.append(yy)
	xx=xx+xmax/nb_pts
	yy=pepite+seuil*(1-math.exp(-3*((xx/portee)**2)))


with open('op_data_krig.csv', newline='') as csvfile:
    reader=csv.DictReader(csvfile)
    for row in reader:
        xexp.append(float(row["x"]))
        yexp.append(float(row["y"]))


plt.scatter(xexp,yexp)
plt.plot(x,y)
plt.title("Variogramme")
#plt.legend()
plt.show()


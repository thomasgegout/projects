#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h> 
#include<time.h> 

#include "simplexe.h"

bool egalite(float a, float b){
	//test d'égalité entre 2 flottants à 0.01 près
	
	return (a-b)<=0.000001 && -0.000001<=(a-b);
}

mat cree_matrice(int n , int p){
	//crée une matrice de n lignes et p colonnes remplie avec des 0
	mat ma=(mat) malloc(sizeof(struct matrice)) ;
	float** M =(float**) malloc(sizeof(float*)*n) ;
	for(int i=0 ; i<n ; i++){
		float* m=(float*) malloc(sizeof(float)*p) ;
		for(int j=0 ; j<p ; j++){
			m[j]=0 ;	
		}
		M[i]=m ;	
	}
	ma->n=n ;
	ma->p=p ;
	ma->M=M ;
	return ma ;
}

void libere_matrice(mat m){
	//libère m
	for(int i=0 ; i<m->n ; i++){
		free(m->M[i]) ;
	}
	free(m->M) ;
	free(m) ;
}
	
void print_matrice(mat m){
	//affiche m
	printf("| ") ;
	for(int i=0 ; i<m->n ; i++){	
		for(int j=0 ; j<m->p ; j++){
			if (m->M[i][j]>=0){
				printf(" %.2f ",m->M[i][j]) ;
			}
			else{
				printf("%.2f ",m->M[i][j]) ;
			}
		}
		if(i!=m->n-1) 
			printf("|\n| ") ;
	}
	printf("|\n") ;
}

void printres(mat m, int n){
    //affiche la facture finale de m
    printf("%f",-m->M[m->n-1][m->p-1]+0.0005*0.10*n);
}

//on définit ici les 3 opérations sur les lignes nécessaires à l'élimination de Gauss-Jordan

void multiplie(mat m, int l, float k){
	//multiplie la ligne l par k
	for(int j=0 ; j<m->p ; j++){
		m->M[l][j]=m->M[l][j]*k ;
	}
}

void ajoute(mat m, int l, float k, int ll){
	//ajoute la ligne ll multipliée par k à la ligne l
	for(int j=0 ; j<m->p ; j++){
		m->M[l][j]=m->M[l][j] + k*m->M[ll][j] ;
	}
}

void echange(mat m, int l, int ll){
	//échange les lignes l et ll
	int p=m->p ;
	float temp ;
	for(int j=0 ; j<p ; j++){
		temp=m->M[l][j] ;
		m->M[l][j]=m->M[ll][j] ;
		m->M[ll][j]=temp ;
	}
}

void pivot_gauss(mat m, int pl, int pc){
	//effectue l'étape du pivot de gauss pour le pivot m->M[pl][pc] 
	if(!egalite(m->M[pl][pc],0)){
		multiplie(m,pl,1.0/m->M[pl][pc]) ;
		for(int i=0 ; i<m->n ; i++){
			if(i!=pl){
				ajoute(m, i, (-1.0)*m->M[i][pc], pl) ;
			}
		}
	
	}
}

//opérations nécessaires au simplexe + simplexe

int pivot_colonne_min(float* tab, int n){
	//retourne l'indice du min des éléments de tab sur [0..n-1[
	int i=0 ;
	float min=tab[0] ;
	int j=0 ;
	while(i<n-1){
		if(min>tab[i]){
			j=i ;
			min=tab[i] ;
		}
		i++ ;
	}
	return j ;
}

int pivot_colonne_max(float* tab, int n){
	//retourne l'indice du max des éléments de tab sur [0..n-1[
	//hyp n est la taille de tab
	int i=0 ;
	float max=tab[0] ;
	int j=0 ;
	while(i<n-1){
		if(max<tab[i]){
			j=i ;
			max=tab[i] ;
		}
		i++ ;
	}
	return j ;
}

int pivot_ligne(mat m, int pc){
	//hyp : pc est l'indice de la colonne de pivot
	//choisit la ligne de pivot avec le critère du quotient
	float min=0 ;
	int i=0 ;
	while((m->M[i][pc]<=0) && i< m->n-1){
		i++;
	}
	min=m->M[i][m->p-1]/m->M[i][pc] ;
	int o=i ;
	for(int k=o ; k<m->n-1 ; k++){	
		if(m->M[k][pc]>0){
			float r=m->M[k][m->p-1]/m->M[k][pc] ;
			if(r<min){
				min=r ;
				i=k ;
			}
		}
	}
	return i ;
}

void simplexe_min(mat m){
	//méthode du simplexe pour un pb de minimisation
	bool b=true ;    
	while(b){	
		int pc=pivot_colonne_min(m->M[m->n-1],m->p) ;
		//printf("%d\n",pc) ;
		b=false ;
		if(m->M[m->n-1][pc]<0){
			b=true ;
			int pl=pivot_ligne(m,pc) ; 
      	   		//printf("%d et %d\n",pl,pc) ;
			pivot_gauss(m,pl,pc) ;		
		}
	}	
}  

void simplexe_max(mat m){
	//méthode du simplexe pour un pb de maximisation
	bool b=true ; 
	while(b){	
		int pc=pivot_colonne_max(m->M[m->n-1],m->p) ;
		//printf("%d\n",pc) ;
		b=false ;
		if(m->M[m->n-1][pc]>0){
			b=true ;
			int pl=pivot_ligne(m,pc) ; 
      	          	//printf("%d\n",pl) ;
			pivot_gauss(m,pl,pc) ;
		}
	}	
}

mat entree(int n, float* pconso, float* pprod, float* ca, float* cv, float* pres_min, float* pres_max, float Enom, float SOCstart, float SOCmin, float SOCmax, float SOCend){
	//n le nombre d'heures
	//pconso tableau de la consommation
	//pprod tableau de la production
	//pres_min tableau des flux min (pres=pa-pv)
	//pres_max tableau des flux max 
	//Enom l'énergie nominale de la batterie (la capacité en gros)
	//SOC (soc : state of the charge) en %
	//construit la matrice adaptée au pb linéaire pour le simplexe
	int nn = 5*n + 1 + 1 ;
	int pp = 3*n + 5*n + 1 + 1 ; 
	mat m=cree_matrice(nn, pp) ;
	
	//première contrainte : dPpv>=0 i.e. Pv+Pprod_ch<=Pprod
	for(int i=0 ; i<n ; i++){
		m->M[i][i+n]=1 ;
		//pour Pv
		//pour Pprod_ch
		m->M[i][i+2*n]=1 ;
		//pour la dernière colonne
		m->M[i][pp-1]=pprod[i]+0.0005 ;
	}

	//deuxième et troisième contraintes: -Pa+Pv<=-Pres_min et Pa-Pv<=Pres_max
	for(int i=0 ; i<n ; i++){
		//pour Pa 
		m->M[i+n][i]= -1 ;
		m->M[i+2*n][i]= 1 ;
		//pour Pv 
		m->M[i+n][i+n]= 1 ;		
		m->M[i+2*n][i+n]= -1 ; 
		//pour la dernière colonne
		m->M[i+n][pp-1]= -200*pres_min[i] ;
		m->M[i+2*n][pp-1]= 200*pres_max[i] ;
	}


	//quatrième et cinquième contrainte
	float somme_conso=0 ; 
	for(int i=0 ; i<n ; i++){
		for(int j=0 ; j<i+1 ; j++){
			//Pour Pa
			m->M[i+3*n][j]=-1 ;
			m->M[i+4*n][j]=1 ;
			
			//Pour Pprod_ch
			m->M[i+3*n][j+2*n]=-1 ;
			m->M[i+4*n][j+2*n]=1 ;
		}
		if( 120<n && n<=168){
			somme_conso=somme_conso+pconso[i]*0 ;
		}
		else{
			somme_conso=somme_conso+pconso[i] ;
		}
		//pour la dernière colonne 
		m->M[i+3*n][pp-1]=(Enom/100)*(SOCstart-SOCmin)-somme_conso ;
		m->M[i+4*n][pp-1]=(Enom/100)*(SOCmax-SOCstart)+somme_conso ;
	}
	
	//septième contrainte 
	for(int i=0 ; i<n ; i++){
		//pour Pa
		m->M[5*n][i]= -1 ; 
		//pour Pprod_ch		
		m->M[5*n][i+2*n]=-1 ;
	}
	m->M[5*n][pp-1]=(Enom/100)*(SOCstart-SOCend)-somme_conso ; 
	
	//variables d'écart
	for(int i=3*n ; i<pp-1 ; i++){
		m->M[i-3*n][i]=1 ;
	}
	
	//dernière ligne 
	for(int j=0 ; j<n ; j++){
		m->M[nn-1][j]=ca[j] ;
		m->M[nn-1][j+n]=-cv[j] ;
	}
	return m ;
}



mat phase1_v2(mat mmm){
	//construit une matrice de notre pb adaptée au simplexe
	// n est le nombre d'heures, p un tableau de taille n pour la production
	// d un tableau de taille n pour la demande, c la capacité de la batterie
	// c un tableau de taille n pour le prix de l'achat
	// cp un tableau de taille n pour le prix de la vente 
	//pour les vraies variables
	
	//etape 1 v2 (construit la matrice à partir de la matrice adaptée au simplexe)
	int nn= mmm->n ;
	int pp= mmm->p +1 ;
	mat m=cree_matrice(nn,pp) ;
	
	for(int i=0 ; i<nn-1 ; i++){
		for(int j=0 ; j<pp-2 ; j++){
			m->M[i][j]=mmm->M[i][j] ;
		}
		m->M[i][pp-2]=-1 ;
		m->M[nn-1][pp-2]=1 ;
		m->M[i][pp-1]=mmm->M[i][pp-2] ;
	}
	m->M[nn-1][pp-2]=1 ;
	//printf("\n") ;
	//print_matrice(m) ;
	//printf("\n") ;
	
	//pour obtenir le min des éléments sur la dernière colonne  (Etape 2)
	int i=0 ;
	float min=m->M[0][pp-1] ;
	int ii=0 ;
	while(i<nn){
		if(min>m->M[i][pp-1]){
			ii=i ;
			min=m->M[i][pp-1] ;
		}
		i++ ;
	}
	pivot_gauss(m,ii,pp-2) ;
	//print_matrice(m) ;
	//printf("\n") ;
	
	//Etape 3
	simplexe_min(m) ;
	//print_matrice(m) ;
	//printf("\n") ;
	
	//Etape 4
	//on retire l'avant dernière colonne (celle de x0)
	pp=pp-1 ;
	mat mm=cree_matrice(nn, pp) ;
	for(int i=0 ; i<nn ; i++){
		for(int j=0 ; j<pp-1 ; j++){
			mm->M[i][j]=m->M[i][j] ;	
		}
		//pour la dernière colonne de mm 
		mm->M[i][pp-1]=m->M[i][pp] ;
	}
	
	//on remplit la dernière ligne de mm
	for(int j=0 ; j<nn ; j++){
		//derniere ligne
		mm->M[nn-1][j]=mmm->M[nn-1][j] ;
	}
	
	//print_matrice(mm) ; //c'est là que le coeff tout en bas à droite doit être nul 
	//printf("\n") ;
	
	//on pivote les coeffs correspondant à ceux de la base
	for(int j=0 ; j<pp-1 ; j++){
		int pl=-1 ;
		for(int i=0 ; i<nn-1 ; i++){
			if(!egalite(mm->M[i][j],0) && pl!=-1){
				pl=-1 ;
				i=nn-1 ;
			}
			else if(egalite(mm->M[i][j],1)){
				pl=i ;
			}
		}
		if(pl!=-1)
			pivot_gauss(mm,pl,j) ;
	}
	//print_matrice(mm) ;
	//printf("\n") ;
	
	libere_matrice(m) ;
	return mm ;
}

res_tab var_res (mat m){
//Renvoie les tableaux des valeurs de variables de m
	int n=(m->p-2)/8 ;
	float* tab_a=(float*) malloc(sizeof(float)*n);
	float* tab_v=(float*) malloc(sizeof(float)*n);
	float* tab_p=(float*) malloc(sizeof(float)*n);
	for(int i=0 ; i<n ; i++){
		tab_a[i]=0 ;
		tab_v[i]=0 ;
		tab_p[i]=0 ;
	}
	for (int j=0; j<3*n; j++){
		bool consider=true;
		int i=0;	
		int cpt=0;
		int ind;
		while (consider && i<m->n){
			if (egalite(m->M[i][j],1)){
				if (cpt>=1){
					consider=false;
				}
				else{
					ind=i;
					cpt++;
				}
			}
			else if (!(egalite(m->M[i][j],0))){
				consider=false;
				}
			i++;
		}
		float res;
		if (cpt==1 && consider)
			res=m->M[ind][m->p-1];
		else
			res=0.;
		if (j<=n)
			tab_a[j]=res;
		else if (j<=2*n)
			tab_v[j%n]=res;
		else 
			tab_p[j%n]=res;
	}
	res_tab result;
	result.size=n;
	result.tab_ach=tab_a;
	result.tab_ven=tab_v;
	result.tab_prod=tab_p;
	return result;
}

void print_var (res_tab rtb,float* p,float* d){
//Affiche les opérations correspondant a rtb
	for (int i=0; i<rtb.size ; i++){
		if (i<10)
			printf("%dh  |ea : %2f |ev : %2f |prod_ch %2f |p : %2f |d : %2f \n",i,rtb.tab_ach[i],rtb.tab_ven[i],rtb.tab_prod[i],p[i],d[i]);
		else
			printf("%dh |ea : %2f |ev : %2f |prod_ch %2f |p : %2f |d : %2f \n",i,rtb.tab_ach[i],rtb.tab_ven[i],rtb.tab_prod[i],p[i],d[i]);
	}
}

void libere_res (res_tab rtb){
//Libère les tableaux de rtb
	free(rtb.tab_ach);
	free(rtb.tab_ven);
	free(rtb.tab_prod);
}


float* stock(int n, float* ea, float* p3, float* d, float C, float s){
	//calcule le tableau des stocks, s étant le stock initial
	float* stock= malloc(sizeof(float)*(n+1)) ;
	stock[0]= s ;
	for(int i=1 ; i<n+1 ; i++){
		float nouv=stock[i-1]-(100*1)/(C)*(d[i-1]-ea[i-1]-p3[i-1]);
		if (nouv>100.0) {
			stock[i]=100.0;
		}
		else if (nouv<0.0){
			stock[i]=0.00;
		}
		else {
			stock[i]=nouv;
		}
	}
	return stock ;
}

float* dPpv(int n, float* ev, float* p3, float* p){
	//calcule le talbeau de la puissance dégradée
	float* dPpv = (float*) malloc(sizeof(float)*n) ;
	for(int i=0 ; i<n ; i++){
		dPpv[i]= p[i]-p3[i]-ev[i]+0.000005 ;
	}
	return dPpv ; 
}

float* pst(int n, float* ea, float* p3, float* d){
	//calcule le flux au niveau du stockage
	float* pst = (float*) malloc(sizeof(float)*n) ;
	for(int i=0 ; i<n ; i++){
		pst[i]= d[i]-ea[i]-p3[i] ;
	}
	return pst  ; 

}	

/*
float* pconso(int n, float* ea, float* pst, float* p3){
	//calcule la puissance apporté à la consommation 
	float* pconso = (float*) malloc(sizeof(float)*n) ;
	for(int i=0 ; i<n ; i++){
		pconso[i]= ea[i]+p3[i]+pst[i] ;
	}
	return pconso  ; 
}
*/

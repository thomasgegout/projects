# Créé par Tom, le 18/01/2023 en Python 3.7
import csv
import matplotlib.pyplot as plt
import numpy as np

h=[]
ach=[]
ven=[]
stk=[]
test=[]
test2=[]
with open('op_data.csv', newline='') as csvfile:
    reader=csv.DictReader(csvfile)
    for row in reader:
        h.append(float(row["h"]))
        ach.append(float(row["ea"]))
        ven.append(float(row["ev"]))
        stk.append(float(row["stk"]))
        test.append(float(row["h"])+0.3)
        test2.append(float(row["h"])+0.6)

plt.bar(h,ach,width=0.3,align="center",color="blue",label="achat")
plt.bar(test,ven,width=0.3,color="orange",align="center",label="vente")
plt.bar(test2,stk,width=0.3,color="green",align="center",label="stock")
plt.title("Operations et stock en fonction des heures")
plt.legend()
plt.show()



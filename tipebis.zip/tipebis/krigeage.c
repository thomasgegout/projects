#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h> 
#include<math.h>
#include<time.h>

#include"tab.h" 
#include"donnees.c"

struct plan_d_experience{
	int nbe ; //nombre d'essais
	int n ; //taille des vecteurs
	float** xmatrice ; //matrice des vecteurs (points testés) de taille n*nbe
	float* ytab ; //tableau des réponses associées aux vecteurs
	int nmax ; //taille réelle de xmatrice et ytab (pour faire des tableaux dynamiques)
	//pour normaliser et dénormaliser facilement : 
	float* ximin ; //tableau contenant les min de chaque composantes des vecteurs de xmatrice
	float* ximax ;
	float ymin ;
	float ymax ; 	
};

typedef struct plan_d_experience plan_exp ;

float distance(int n, float* v1, float* v2){
	//calcule la distance euclidienne entre v1 et v2, deux vecteurs de taille n 
	float somme=0 ;
	for(int i=0 ; i<n ; i++){
		somme=somme+(v1[i]-v2[i])*(v1[i]-v2[i]) ;
	}
	return sqrtf(somme) ;
}

void normalise_pde(plan_exp* pde){
	//normalise les vecteurs du plan d'expérience pde
	
	
	//calcul de ximin[i], ximax[i], ymin et ymax
	for(int k=0 ; k<pde->n ; k++){
		pde->ximin[k]= pde->xmatrice[0][k] ;
		pde->ximax[k]= pde->xmatrice[0][k] ;
	}
	float ymin=pde->ytab[0] ;
	float ymax=pde->ytab[0] ;
	
	for(int j=1 ; j< pde->nbe ; j++){
	
		for(int k=0 ; k<pde->n ; k++){
			if(pde->xmatrice[j][k]<pde->ximin[k]){
				pde->ximin[k]=pde->xmatrice[j][k] ; 
			}
			if(pde->xmatrice[j][k]>pde->ximax[k]){
				pde->ximax[k]=pde->xmatrice[j][k] ;
			}
		}
		if(ymin>pde->ytab[j]){
			ymin=pde->ytab[j] ;
		}
		if(ymax<pde->ytab[j]){
			ymax=pde->ytab[j] ;
		}
	}
	pde->ymin = ymin ;
	pde->ymax = ymax ;
	
	//normalisation des x et des y 
	for(int i=0 ; i< pde->nbe ; i++){
		for(int j=0 ; j<pde->n ; j++){
			pde->xmatrice[i][j]=(pde->xmatrice[i][j]-pde->ximin[j])/(pde->ximax[j]-pde->ximin[j]) ;
		}
		pde->ytab[i]=(pde->ytab[i]-pde->ymin)/(pde->ymax-pde->ymin) ;
	}

}

void denormalise_pde(plan_exp* pde){
	//dénormalise les vecteurs du plan d'expérience pde 
	 
	for(int i=0 ; i< pde->nbe ; i++){
		for(int j=0 ; j<pde->n ; j++){
			pde->xmatrice[i][j]=pde->xmatrice[i][j]*(pde->ximax[j]-pde->ximin[j])+pde->ximin[j] ;
		}
		pde->ytab[i]=pde->ytab[i]*(pde->ymax-pde->ymin)+pde->ymin ;
	}
}

mat matrice_distances(plan_exp pde){
	//retourne la matrice m telle que m->M[i][j]=d(Xi,Xj)
	int n = pde.nbe ;
	mat m=cree_matrice(n,n) ;
	for(int i=0 ; i<n ; i++){
		for(int j=i+1 ; j<n ; j++){
			float d= distance(pde.n,pde.xmatrice[i],pde.xmatrice[j]) ;
			m->M[i][j]=d ;
			m->M[j][i]=d ;
		}
		m->M[i][i]=distance(pde.n,pde.xmatrice[i],pde.xmatrice[i]) ;
	}
	return m ;
}

float variogramme(float* tab, int n){
	//calcule une estimation de la valeur du variogramme en la distance d y(d)
	//tab contient les différences des paires dont les points sont espacées d'une distance h
	//tab est de taille n 
	float vario=0 ; 
	for(int i=0 ; i<n ; i++){
		vario=vario+tab[i]*tab[i] ;
	}
	vario=vario/(2*n) ;
	return vario ; 
}


struct parametres_variogramme_g{
	float a ; //la portée
	float c ; //le seuil
	float c0 ; //l'effet de pépite
};

typedef struct parametres_variogramme_g* parametres_vg ;

float variogramme_gaussien(float d, float a, float c0, float c){
	//a représente la portée
	//c0 représente l'effet de pépite 
	//c représente le seuil
	if(d==0){
		return 0 ;
	}
	else{
		return c0+c*(1-exp(-3*pow(d/a,2))) ;
	}
}

mat matrice_variogramme_experimental(plan_exp pde, mat D){
	//retourne la matrice M telle que M[i,j]=y(D[i,j]) avec y le variogramme 
	float epsilon=0.63 ;
	float epsilon2=0.14 ;
	int n = D->n ;
	mat mvar=cree_matrice(n,n) ;
	float* tab=(float*) malloc(sizeof(float)*((n*(n-1))/2) ) ; 

	for(int ii=0 ; ii<n ; ii++){
		for(int jj=ii+1 ; jj<n ; jj++){
		
			float d=D->M[ii][jj] ;
			//on construit le tableau des Yi-Yj où Xi et Xj sont distants de d à epsilon près
			int cpt=0 ;
			for(int i=0 ; i<n ; i++){
				for(int j=i+1 ; j<n ; j++){
					if(D->M[i][j]<=d*(1+epsilon)+epsilon2 && D->M[i][j]>=d*(1-epsilon)-epsilon2){
						tab[cpt]=pde.ytab[i]-pde.ytab[j] ;
						cpt++ ; 
					}
				}
			}
			
			mvar->M[ii][jj]= (variogramme(tab,cpt)) ;
			mvar->M[jj][ii]= mvar->M[ii][jj] ;
			
		}
		//mvar->M[ii][ii]=0 ;
	}
	free(tab) ;
	//print_matrice(mvar) ;
	//printf("\n") ;
	//print_matrice(D) ;
	return mvar ; 
}

//méthode des moindres carrés

mat jacobienne(float* dists, int m, float a, float c0, float c){
	//renvoie la  matrice jacobienne de la fonction
	//m le nombre de distances dans dists 
	mat J=cree_matrice(m,3) ; 
	for(int i=0 ; i<m ; i++){
		J->M[i][0]=1 ; //dérivée partielle par rapport à c0
		J->M[i][1]=(1-exp(-3*pow(dists[i]/a,2))) ; //dérivée partielle par rapport à c
		J->M[i][2]=-6*pow(dists[i],2)*c*pow(1/a,3)*exp(-3*pow(dists[i]/a,2)) ; //dérivée partielle par rapport à a
	}
	return J ;
}

mat transpose_matrice(mat m){
	//renvoie la transposée de m
	mat mt=cree_matrice(m->p,m->n) ;
	for(int i=0 ; i<mt->n ; i++){
		for(int j=0 ; j<mt->p ; j++){
			mt->M[i][j]=m->M[j][i] ;
		}
	}
	return mt ;
}

mat inverse_matrice(mat m){
	//inverse m si elle est inversible avec l'élimination de Gauss-Jordan
	//retourne la matrice nulle si m pas inversible
	mat minv=cree_matrice(m->n, m->n) ;
	mat mplus=cree_matrice(m->n, 2*m->n) ;
	for(int i=0 ; i<m->n ; i++){
		for(int j=0 ; j<m->p ; j++){
			mplus->M[i][j]=m->M[i][j] ;
		}
	}	
	
	for(int i=0 ; i<m->n ; i++){
		mplus->M[i][i+m->n]=1 ;
	}
		
	int i ;
	//elimination de Gauss-Jordan
	for(int k=0 ; k<m->n ; k++){
		i=k ;
		while(i<m->n && mplus->M[i][k]==0){
			i++ ;
		}
		if(i<m->n){
			if(i!=k)
				echange(mplus,i,k) ;
			pivot_gauss(mplus,k,k) ;
		}
		else{
			return minv ;
		}
	}
	
	for(int i=0 ; i<m->n ; i++){
		for(int j=0 ; j<m->n ; j++){
			minv->M[i][j]=mplus->M[i][j+m->p] ;
		}
	}
	
	return minv ; 
}

mat produit_mat(mat m1, mat m2){
	//effectue le produit matriciel m1 * m2
	//hyp : m1->p=m2->n 
	int n=m1->n ;
	mat mp=cree_matrice(m1->n,m2->p) ;
	
	for(int i=0 ; i<m1->n ; i++){
		for(int j=0 ; j<m2->p ; j++){
			for(int l=0 ; l<m1->p ; l++){
				mp->M[i][j]=mp->M[i][j]+(m1->M[i][l])*(m2->M[l][j]) ;
			}
		}
	}	
	return mp ;
}

parametres_vg parametres_initiaux(float* x, float* y, int n){
	//créé des paramètres initiaux pour trouver f tq y=f(x,vg)
	// x et y tableaux de n valeurs 
	parametres_vg pinit=(parametres_vg) malloc(sizeof(struct parametres_variogramme_g)) ;

	pinit->c0=0.1 ; 
	pinit->c=1 ;
	pinit->a=1 ;
	printf("pinit : a,c,c0 : %f,%f,%f\n",pinit->a,pinit->c,pinit->c0) ;
	return pinit ;
}

parametres_vg moindres_carres(float* x, float* y, int n){
	//méthode des moindres carrés pour trouver f tq y=f(x,vg)
	// x et y tableaux de n valeurs 
	parametres_vg pinit=parametres_initiaux(x,y,n) ;
	
	mat JJ=jacobienne(x, n, pinit->a, pinit->c0, pinit->c) ;
	float d0= 0 ; 
	float d1= 0 ;
	float d2= 0 ;
	for(int i=0 ; i<n ; i++){
		float ri=y[i]-variogramme_gaussien(x[i],pinit->a,pinit->c0,pinit->c) ;
		d0=d0+ri*(-JJ->M[i][0]) ;
		d1=d1+ri*(-JJ->M[i][1]) ;
		d2=d2+ri*(-JJ->M[i][2]) ;
	}
	d0=2*d0 ;
	d1=2*d1 ;
	d2=2*d2 ;

	libere_matrice(JJ) ;

	float epsilon=0.002 ;
	int k=0 ;
	while( !( (d0<epsilon && -epsilon<d0) && (d1<epsilon && -epsilon<d1) && (d2<epsilon && -epsilon<d2) )){
		mat J=jacobienne(x, n, pinit->a, pinit->c0, pinit->c) ;
		mat Jt=transpose_matrice(J) ;
		mat p=produit_mat(Jt,J) ;
		mat inv=inverse_matrice(p) ;
		
		
		mat dY=cree_matrice(n,1) ; 
		for(int i=0 ; i<n ; i++){
			dY->M[i][0]= y[i]-variogramme_gaussien(x[i],pinit->a,pinit->c0,pinit->c) ;
		}
		
		mat temp=produit_mat(inv,Jt) ;
		mat dB=produit_mat(temp,dY) ;
		
		pinit->c0=pinit->c0+dB->M[0][0] ;
		pinit->c=pinit->c+dB->M[1][0] ;
		pinit->a=pinit->a+dB->M[2][0] ;
		
		
		//printf("a,c,c0 : %f,%f,%f\n",pinit->a,pinit->c,pinit->c0) ;

		libere_matrice(J) ;
		
		mat JJ=jacobienne(x, n, pinit->a, pinit->c0, pinit->c) ;
		d0= 0 ; 
		d1= 0 ;
		d2= 0 ;
		
		for(int i=0 ; i<n ; i++){
			float ri=y[i]-variogramme_gaussien(x[i],pinit->a,pinit->c0,pinit->c) ;
			d0=d0+ri*(-JJ->M[i][0]) ;
			d1=d1+ri*(-JJ->M[i][1]) ;
			d2=d2+ri*(-JJ->M[i][2]) ;
		}
		d0=2*d0 ;
		d1=2*d1 ;
		d2=2*d2 ;

		k++ ; 
		
		//printf("d2,d1,d0 : %f,%f,%f\n",d2,d1,d0) ;
		
		libere_matrice(Jt) ;
		libere_matrice(p) ;
		libere_matrice(inv) ;
		libere_matrice(temp) ;
		libere_matrice(dY) ;
		libere_matrice(dB) ;
		libere_matrice(JJ) ;
	}
	
	printf("pfinaux : a,c,c0 : %f,%f,%f\n",pinit->a,pinit->c,pinit->c0) ;
	return pinit ; 
}


mat matrice_variances_plus(mat V){
	//retourne la matrice V+
	int n = V->n ;
	mat vplus=cree_matrice(n+1,n+1) ;
	for(int i=0 ; i<n ; i++){
		for(int j=0 ; j<n ; j++){
			vplus->M[i][j]= V->M[i][j];
			vplus->M[n][j]= 1 ; 
		}
		vplus->M[i][n]= 1 ;
		vplus->M[n][i]= 1 ;
	}
	vplus->M[n][n]=0 ; 
	return vplus ;
}

mat resout_systeme(mat vplus, mat B){ 
	//renvoie X tq Vplus*X=B
	//hyp : taille de B = Vplus->n
	mat vplusinv=inverse_matrice(vplus) ;

	mat p=produit_mat(vplusinv, B) ;
	libere_matrice(vplusinv) ;
	return p ;
}

void extract_var_krig(float* x, float* y, int n){
	//Ecrit dans le fichier "op_data.csv" les variables obtenues à la fin
	FILE *file_ptr;
	file_ptr=fopen("op_data_krig.csv","w");
	fprintf(file_ptr,"x,y\n");
	int i;
	for (i=0 ; i<n ; i++){
		fprintf(file_ptr, "%f,%f\n",x[i],y[i]);
	}
	fclose(file_ptr);
}

void extract_var_krig_2(float* x, float* ps, float* y, float* s, int n){
	//Ecrit dans le fichier "op_data.csv" les variables obtenues à la fin
	FILE *file_ptr;
	file_ptr=fopen("op_data_krig_2.csv","w");
	fprintf(file_ptr,"x,ps,y,s\n");
	int i;
	for (i=0 ; i<n ; i++){
		fprintf(file_ptr, "%f,%f,%f,%f\n",x[i],ps[i],y[i],s[i]);
	}
	fclose(file_ptr);
}


void extract_var_krig_3(float* xpde, float* pspde, float* ypde, int nbe){
	FILE *file_ptr ;
	file_ptr=fopen("op_data_krig_3.csv","w") ;
	fprintf(file_ptr,"xpde,pspde,ypde\n") ;
	int i ;
	for (i=0 ; i<nbe ; i++){
		fprintf(file_ptr, "%f,%f,%f\n",xpde[i],pspde[i],ypde[i]);
	}
	fclose(file_ptr) ;
}

parametres_vg p_variogramme_gaussien_e(plan_exp* pde){
	//calcule le variogramme gaussien correspond le mieux au plan d'expérience pde

	int n=pde->nbe ;

	mat D =matrice_distances(*pde) ;

	mat v=matrice_variogramme_experimental(*pde, D) ;

	int m= (n*(n-1))/2 ; //nombre de couples où les deux éléments du couples sont différents
	float* x=(float*) malloc(sizeof(float)*m) ; //contient les distances
	float* y=(float*) malloc(sizeof(float)*m) ; //contient y(x[i]) avec y le variogramme expérimental
	int cpt = 0 ; 
	for(int i=0 ; i<n ; i++){
		for(int j=i+1 ; j<n ; j++){
			x[cpt] = D->M[i][j] ;
			y[cpt] = v->M[i][j] ;
			cpt++ ;
		}
	}
	extract_var_krig(x,y,m) ;
	parametres_vg param=moindres_carres(x,y,m) ;
	libere_matrice(v) ;
	libere_matrice(D) ;
	free(x) ;
	free(y) ;
	return param ; 
}

parametres_vg p_variogramme_gaussien(plan_exp* pde){
	//calcule le variogramme gaussien correspond le mieux au plan d'expérience pde

	int n=pde->nbe ;

	mat D=matrice_distances(*pde) ;

	mat v=matrice_variogramme_experimental(*pde, D) ;

	int m=(n*(n-1))/2 ; //nombre de couples où les deux éléments du couples sont différents
	float* x=(float*) malloc(sizeof(float)*m) ; //contient les distances
	float* y=(float*) malloc(sizeof(float)*m) ; //contient y(x[i]) avec y le variogramme expérimental
	int cpt = 0 ; 
	for(int i=0 ; i<n ; i++){
		for(int j=i+1 ; j<n ; j++){
			x[cpt] = D->M[i][j] ;
			y[cpt] = v->M[i][j] ;
			cpt++ ;
		}
	}
	parametres_vg param=moindres_carres(x,y,m) ;
	libere_matrice(D) ;
	libere_matrice(v) ;
	free(x) ;
	free(y) ;
	return param ; 
}

struct couple_s{
	float f1 ;
	float f2 ;
};

typedef struct couple_s couple ;

couple krigeage(plan_exp* pde, float* x0, parametres_vg param){
	//calcul de V avec le modèle de variogramme gaussien dont les paramètres sont ceux de param  
	int n=pde->nbe ;
	mat D =matrice_distances(*pde) ;
	mat V=cree_matrice(n,n) ;
	for(int i=0 ; i<n ; i++){
		for(int j=i+1 ; j<n ; j++){
			float vgij=variogramme_gaussien(D->M[i][j], param->a, param->c0, param->c) ;
			V->M[i][j]= vgij ;
			V->M[j][i]= vgij ;
		}
	}
	
	mat Vplus=matrice_variances_plus(V) ;
	libere_matrice(V) ;
	
	//on normalise x0
	for(int j=0 ; j<pde->n ; j++){
		x0[j]=(x0[j]-pde->ximin[j])/(pde->ximax[j]-pde->ximin[j]) ;
	}
	
	mat B=cree_matrice(n+1,1) ;
	for(int i=0 ; i<n ; i++){
		B->M[i][0]=variogramme_gaussien(distance(pde->n,x0,pde->xmatrice[i]), param->a, param->c0, param->c) ;
	}
	B->M[n][0]=1 ;
	
	mat lambda=resout_systeme(Vplus, B) ;

	float y0 = 0 ;
	for(int i=0 ; i<n ; i++){
		y0=y0+lambda->M[i][0]*pde->ytab[i] ;
	}
	y0=y0*(pde->ymax-pde->ymin)+pde->ymin ;
	
	//calcul de la variance sur la valeur obtenue
	mat lambdat=transpose_matrice(lambda) ;
	mat p=produit_mat(lambdat,B) ;
	float sigma0 ; 
	if(p->M[0][0]<0){
		sigma0=sqrt(-p->M[0][0]) ;
	}
	else{
		sigma0=sqrt(p->M[0][0]) ;
	}

	libere_matrice(lambdat) ;
	libere_matrice(lambda) ;
	libere_matrice(p) ;
	libere_matrice(B) ;
	libere_matrice(Vplus) ;
	libere_matrice(D) ;
	
	couple c={y0,sigma0} ;
	
	return c ; 
}

plan_exp* cree_plan_exp(int n, float* pconso, float* pprod, float* ca, float* cv, float* pres_min, float* pres_max, float SOCstart, float SOCmin, float SOCmax, float SOCend, float Enommax, float Enommin, float s_panneaux_solaires_max, float pbat, float psol, int nbe){
	//crée un plan d'expérience 
	//nbe le nombre d'essais
	plan_exp* pde=(plan_exp*) malloc(sizeof(plan_exp)) ;
	pde->nbe=nbe*nbe ;
	pde->n=2 ;
	pde->ximin=(float*) malloc(sizeof(float)*pde->n) ;
	pde->ximax=(float*) malloc(sizeof(float)*pde->n) ;
	pde->ymin=0 ; 
	pde->ymax=0 ; 
	
	for(int k=0 ; k<pde->n ; k++){
		pde->ximin[k]=0 ; 
		pde->ximax[k]=0 ; 
	}
	
	pde->nmax=2*nbe*nbe ;
	pde->xmatrice=(float**) malloc(sizeof(float*)*pde->nmax) ;
	pde->ytab=(float*) malloc(sizeof(float)*pde->nmax) ;
	float Enom=Enommin ;
	int k=0 ;
	float facture ;
	
	for(int j=0 ; j<nbe ; j++){
		float nprod[n] ;
		float s=6 ;
		//cfacture=cfacture+Enom*psol ; 
		for(int i=0 ; i<nbe ; i++){
			for(int jj=0 ; jj<n ; jj++){
				nprod[jj]=pprod[jj]*s ;
			}
			mat mmm=entree(n,pconso,nprod,ca,cv,pres_min,pres_max,Enom,SOCstart,SOCmin,SOCmax,SOCend) ;
			mat mm2=phase1_v2(mmm) ;
			simplexe_min(mm2) ;
			//printres(mm2,j*24) ;
			facture=-mm2->M[mm2->n-1][mm2->p-1]+0.0005*0.10*n;
			
			libere_matrice(mmm) ;
			libere_matrice(mm2) ;
			float* tabl=(float*) malloc(sizeof(float)*pde->n) ;

			tabl[0]=Enom ;
			tabl[1]=s ;

			pde->xmatrice[k]=tabl ;
			pde->ytab[k]=facture+(s*psol+Enom*pbat)*n/24 ;
			s=s+(s_panneaux_solaires_max-6)/(nbe-1) ;
			k++ ;
		}
		Enom=Enom+Enommax/(nbe-1) ;
	}
	
	return pde ;
}

void print_plan_exp(plan_exp* pde){
	//affiche les tableaux xmatrice et y tab
	printf("xmatrice :\n") ;
	for(int i=0 ; i<pde->nbe ; i++){
		printf("[") ;
		for(int j=0 ; j<pde->n-1 ; j++){
			printf("%f, ",pde->xmatrice[i][j] ) ;
		}
		printf("%f ] %f, ",pde->xmatrice[i][pde->n-1],pde->ytab[i]) ;
	}
	printf("\n") ;

}

void ajoute_plan_exp(plan_exp* pde, float* xn, float yn){
	//hyp : |xn|==pde->n 
	//ajoute le point xn de facture yn à pde
	if(pde->nmax > pde->nbe){
		pde->xmatrice[pde->nbe]=xn ;
		pde->ytab[pde->nbe]=yn ; 
		pde->nbe=pde->nbe+1 ;
	}
	else{
		pde->nmax=pde->nmax*2 ; 
		float** xmatrice2=(float**) malloc(sizeof(float*)*pde->nmax) ;
		float* ytab2=(float*) malloc(sizeof(float)*pde->nmax) ;
		for(int i=0 ; i<pde->nbe ; i++){
			xmatrice2[i]=pde->xmatrice[i] ; 
			ytab2[i]=pde->ytab[i] ;
		}
		free(pde->xmatrice) ;
		free(pde->ytab) ;
		pde->xmatrice=xmatrice2 ; 
		pde->ytab=ytab2 ;
		
		pde->xmatrice[pde->nbe]=xn ;
		pde->ytab[pde->nbe]=yn ; 
		pde->nbe=pde->nbe+1 ;
	}
}

bool est_pas_present(plan_exp* pde, float* xn){

	//teste si xn est très proche d'un point présent dans pde
	float epsilon = 0.02 ;
	for(int i=0 ; i<pde->nbe ; i++){
		if(distance(pde->n,xn,pde->xmatrice[i])<epsilon){
			return false ;
		}
	}
	return true ;
}

void libere_plan_exp(plan_exp* pde){
	//libère pde
	for(int i=0 ; i<pde->nbe ; i++){
		free(pde->xmatrice[i]) ;
	} 
	free(pde->xmatrice) ;
	free(pde->ytab) ;
	free(pde) ;
}


//pour EGO

//loi normale : 

float densite_de_proba(float x){
	return 1/sqrt(2*M_PI)*exp(-1/2*x*x) ; 
}

float fonction_de_repartition(float x){
	return 1/2+1/2*erf(x/sqrt(2)) ; 
}

float amelioration_esperee(float ymin, float yest, float sigma){
	//calcule l'amélioration espérée 
	float d=ymin-yest ;
	return d*fonction_de_repartition(d/sigma)+sigma*densite_de_proba(d/sigma) ;
}

void ego(plan_exp* pde, float Enommax, float spmax, int n, float* pconso, float* pprod, float* ca, float* cv, float* pres_min, float* pres_max, float SOCstart, float SOCmin, float SOCmax, float SOCend,float pbat, float psol){
	int nbpts=80 ;
	
	normalise_pde(pde) ;
	
	
	parametres_vg param= p_variogramme_gaussien(pde) ;


	float* xmax=(float*) malloc(sizeof(float)*pde->n) ;
	float xt[2] ;
	xmax[0]=0.1 ; 
	xt[0]=0.1 ; 
	xmax[1]=6 ; 
	xt[1]=6 ; 


	couple temp=krigeage(pde, xt, param) ;
	float eitemp=amelioration_esperee(pde->ymin,temp.f1,temp.f2) ;
	
	float c=0.01 ;
	int k=0 ;
	for(int i=0 ; i<nbpts ; i++){
		c=c+(Enommax-0.1)/nbpts ;
		float s=6.5 ;
		for(int j=0 ; j<nbpts ; j++){
			s=s+(spmax-6.5)/nbpts ;
			xt[0]=c ;
			xt[1]=s ;
			
			temp=krigeage(pde, xt, param) ;
			
			float ei=amelioration_esperee(pde->ymin,temp.f1,temp.f2) ;
			//printf("%f\n",ei) ;
			
			if(ei>eitemp && est_pas_present(pde,xt)){
				eitemp=ei ;
				for(int kk=0 ; kk<pde->n ; kk++){
					xmax[kk]=xt[kk]*(pde->ximax[kk]-pde->ximin[kk])+pde->ximin[kk] ;
				}
			}
			k++ ;
		}
	}
	
	
	printf("[%f,%f]\n", xmax[0],xmax[1]) ;
	
	/*if(xmax[0] <=0.101 && xmax[0]>=0 && xmax[1] <=0.101 && xmax[1]>=-0.1 ){
		
		xmax[0]= rand() % 30 +0.01 ;
		xmax[1]= rand() % 20 ;
	}*/
	
	printf("[%f,%f]\n", xmax[0],xmax[1]) ;
	
	//calcul de la facture du nouveau point
	
	float nprod[n] ;
	for(int jj=0 ; jj<n ; jj++){
			nprod[jj]=pprod[jj]*xmax[1] ;
	}
	
	mat mmm=entree(n,pconso,nprod,ca,cv,pres_min,pres_max,xmax[0],SOCstart,SOCmin,SOCmax,SOCend) ;
	mat mm2=phase1_v2(mmm) ;
	simplexe_min(mm2) ;
	//printres(mm2,j*24) ;
	float facture=-mm2->M[mm2->n-1][mm2->p-1]+0.0005*0.10*n+xmax[1]*psol*n/24+xmax[0]*pbat*n/24 ;
	
	libere_matrice(mmm) ;
	libere_matrice(mm2) ;
	
	denormalise_pde(pde) ;
	ajoute_plan_exp(pde,xmax, facture) ;

	free(param) ;
}

int ind_min_tab(float* tab, int n){
	//retourne l'indice du min de tab, n étant sa taille
	float min=tab[0] ;
	int ind_min=0 ; 
	for(int i=1 ; i<n ; i++){
		if(tab[i]<min){
			min=tab[i] ;
			ind_min=i ;	
		}
	}
	return ind_min ;
}

int main(){
	int j;
	int res=scanf("%d",&j);
	time_t begin=time (NULL);
	
	tab_tab remp=malloc(sizeof(struct tabdonnees));
	recup_tab(remp,"demande_tab_aut.csv");
	
	grandit_tab(remp,j);
	
	float Enommax=200 ;
	float spmax=50 ;
	float pbat=0.126 ;
	float psol=0.082 ;
	int nbe= 4 ;
	
	plan_exp* pde=cree_plan_exp(j*24,remp->dem,remp->prod,remp->c,remp->cp,remp->pres_min,remp->pres_max,0,0,100,0,Enommax,0.01,spmax,pbat,psol,nbe) ;
	
	print_plan_exp(pde) ;	
	printf("\n") ;
	
	int nbajouts=0 ;
	for(int a=0 ; a<nbajouts ; a++ ){
		ego(pde, Enommax, spmax, j*24,remp->dem,remp->prod,remp->c,remp->cp,remp->pres_min,remp->pres_max,0,0,100,0,pbat,psol) ;
	}
	
	print_plan_exp(pde) ;	
	normalise_pde(pde) ;
	parametres_vg param= p_variogramme_gaussien_e(pde) ;
	

	//pour avoir la variation de la facture en fonction de l'énergie nominale et de la surface de panneaux solaires 
	int nbpts=80 ;
	couple* c=(couple*) malloc(sizeof(couple)*nbpts*nbpts) ; 
	float* x=(float*) malloc(sizeof(float)*nbpts*nbpts) ;
	float* ps=(float*) malloc(sizeof(float)*nbpts*nbpts) ;
	float* y=(float*) malloc(sizeof(float)*nbpts*nbpts) ;
	float* s=(float*) malloc(sizeof(float)*nbpts*nbpts) ;

	x[0]=0.001 ; 
	ps[0]=5 ; 
	float xtemp=x[0] ;
	int k=0 ;
	int nnn=nbpts*nbpts ;
	for(int i=0 ; i<nbpts ; i++){

		for(int j=0 ; j<nbpts ; j++){
			if(k+1<nnn){
				x[k+1]=xtemp ;
				ps[k+1]=ps[k]+(spmax+2-4)/nbpts ;
			}
			float tab[2]={x[k],ps[k]} ;
			c[k]=krigeage(pde, tab, param) ;
			y[k]=c[k].f1 ;
			s[k]=c[k].f2 ;
			//printf("%f\n", y[i]) ;
			k++ ; 
		}
		ps[k]=ps[0] ;
		xtemp=x[k]+Enommax/nbpts ;
		x[k]=xtemp ; 
	}

	denormalise_pde(pde) ;
	
	int imin=ind_min_tab(y,nbpts*nbpts) ;
	printf("capacité opti : %f, spanneaux opti ; %f, facture associée : %f\n",x[imin],ps[imin],y[imin]) ;
	
	float* xpde=(float*) malloc(sizeof(float)*pde->nbe) ;
	float* pspde=(float*) malloc(sizeof(float)*pde->nbe) ;
	float* ypde=(float*) malloc(sizeof(float)*pde->nbe) ;
	
	for(int i=0 ; i<pde->nbe ; i++){
		xpde[i]=pde->xmatrice[i][0] ;
		pspde[i]=pde->xmatrice[i][1] ;
		ypde[i]=pde->ytab[i] ;
	}

	extract_var_krig_2( x, ps, y, s, nbpts*nbpts) ; 
	extract_var_krig_3(xpde, pspde, ypde, pde->nbe) ;

	free(x) ;
	free(ps) ;
	free(y) ;
	free(s) ;
	free(c) ;	
	
	free(xpde) ;
	free(pspde) ;
	free(ypde) ;
	
	libere_plan_exp(pde) ;	

	
	libere_tab(remp) ;
	
	
	time_t end=time(NULL);
	unsigned long diff= (unsigned long) difftime (end,begin) ;
	int sec=diff%60 ;
	printf("temps : %ld min %d sec\n",diff/60,sec);
}


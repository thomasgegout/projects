# Créé par Tom, le 15/05/2023 en Python 3.7
import matplotlib.pyplot as plt
import numpy as np
import csv

y=np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23])
p=([2,2,2,2,2,2,2,2,4,8,11,12,11,12.5,12,9,5,3.5,2.5,2.2,2,2,2,2])
soleil=[0,0,0,0,0,0,0.035,0.15,0.345,0.57,0.74,0.86,0.975,1.02,0.95,0.819,0.66,0.44,0.234,0.066,0,0,0,0]

def chebi(n):
    t=np.array([])
    for i in range(n):
        t=np.append([n/2+(n/2)*np.cos((2*i+1)*3.14/(n*2))],t)
    return t

tab=chebi(24)
vmoy=90000/(365*24*60)

def lag(n,t,val):
    X=np.poly1d([1,0])
    P=0
    for i in range(n):
        Li=1
        for j in range(n):
           if(i!=j):
                Li=Li*((X-t[j])/(t[i]-t[j]))
        P=P+(Li*val[i])
    return P

p5=lag(24,tab,p)

tab2=chebi(15)
for i in range(15):
    tab2[i]=tab2[i]+10
pp=[9,12,12.5,12,11,12,12,9.5,4.5,2.5,2.2,2,2,2,2]
for i in range(8):
    pp[i]=p5(tab2[i])

p6=lag(15,tab2,pp)

def p7(p1,p2,i):
    if (i>14):
        return p2(i)
    else:
        return p1(i)

def poly_f(x):
    return vmoy*p7(p5,p6,x)

psol1=lag(24,tab,soleil)
soleil2=[0.57,0.74,0.86,0.975,1.02,0.95,0.819,0.66,0.44,0.234,0.066,0,0,0,0]
for i in range(9):
    soleil2[i]=psol1(tab2[i])
psol2=lag(15,tab2,soleil2)
xso=[]
yso=[]
def polysol(x):
    return p7(psol1,psol2,x)
for i in range(1000):
    xso.append(24*i/1000)
    yso.append(polysol(24*i/1000))

plt.plot(xso,yso)
plt.show()

dx=1/100

x=[]
def deriv(f,x):
    return (f(x+dx)-f(x))/dx

def insertion_list(l,e):
    for i in range(len(l)):
        if e<(l[i]):
            l[i:i]=[e]
            break
    return l

def cout(l):
    val=0
    for i in range(len(l)-1):
        val=val+(deriv(poly_f,l[i]))
    for i in range(len(l)-2):
        if (l[i+1]-l[i])<0.001:
            val=val-0.5
    return val

def liste_point(f,n):
    res=[0,12,23]
    for i in range(n-3):
        max=0
        maxid=0
        for i in range(len(res)-2):
            test=abs(f(res[i+1])-f(res[i]))/(res[i+1]-res[i])
            if test>max:
                max=test
                maxid=i
        nouv=(res[maxid+1]+res[maxid])/2
        res=insertion_list(res,nouv)
    return res

def choix_random(l):
    rdi=np.random.random()
    som=0
    for i in range(len(l)):
        som=som+l[i]
        if som>rdi:
            return i
    return len(l)-1

def liste_point_proba_4(f,n):
    res=[0,12,24]
    for i in range(n-3):
        max=0
        maxid=0
        vals=[]
        for i in range(len(res)-1):
            if res[i+1]-res[i]>0.51:
                vals.append((res[i+1]-res[i])*abs(f(res[i+1])-f(res[i]))+(abs(deriv(f,res[i+1])-deriv(f,res[i])))*(abs(deriv(f,res[i+1])-deriv(f,res[i])))/(res[i+1]-res[i]))
            else:
                vals.append(0)
        som=0
        for i in range(len(vals)):
            som=som+(vals[i])
        valsnorm=[]
        for i in range(len(vals)):
            valsnorm.append(vals[i]/som)
        maxid=choix_random(valsnorm)
        nouv=(res[maxid+1]+res[maxid])/2
        res=insertion_list(res,nouv)
    return res

def trouv_opti_rd(n):
    max=-10000
    res=[]
    for i in range(n):
        consid=liste_point_proba_4(poly_f,24)
        valcon=cout(consid)
        if valcon>max:
            max=valcon
            res=consid
    return res
t=trouv_opti_rd(1000)


xx=[]
yy=[]
for i in range(1000):
    xx.append(i*24/1000)
    yy.append(poly_f(i*24/1000))

j=trouv_opti_rd(10)
print(j,cout(j))
jy=[]
for i in range(len(j)):
    jy.append(poly_f(j[i]))

#resvalid=[0, 3.0, 6.0, 6.75, 7.5, 7.875, 8.25, 8.625, 9.0, 9.375, 9.75, 10.5, 10.875, 11.25, 12, 13.5, 14.25, 15.0, 16.5, 17.25, 18.0, 19.5, 21.0, 24]

print(jy)

with open("demande_tab.csv", "w",newline='') as csvfile:
    colonnes=["x","d","p"]
    writer=csv.DictWriter(csvfile,colonnes)
    writer.writeheader()
    for i in range(len(j)):
       writer.writerow({"x":str(round(j[i],5)),"d":str(round(jy[i],5)),"p":str(round(polysol(j[i]),5))})

with open("demande_tab_bis.csv", "w",newline='') as csvfile:
    colonnes=["x","d","p"]
    writer=csv.DictWriter(csvfile,colonnes)
    writer.writeheader()
    for i in range(len(j)):
       writer.writerow({"x":str(round(y[i],5)),"d":str(round(poly_f(y[i]),5)),"p":str(round(polysol(y[i]),5))})


plt.plot(xx,yy,color="blue")
plt.scatter(j,jy,color="orange")
plt.show()


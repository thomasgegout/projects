# Créé par Tom, le 18/01/2023 en Python 3.7
import csv
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
import math

x=[]
y=[]
x1=[]
x2=[]
ps=[]

xpde=[]
pspde=[]
ypde=[]

with open('op_data_krig_2.csv', newline='') as csvfile:
    reader=csv.DictReader(csvfile)
    for row in reader:
        x.append(float(row["x"]))
        ps.append(float(row["ps"]))
        y.append(float(row["y"]))
        x1.append(float(row["y"])-3*float(row["s"]))
        x2.append(float(row["y"])+3*float(row["s"]))

with open('op_data_krig_3.csv', newline='') as csvfile2:
    reader2=csv.DictReader(csvfile2)
    for row in reader2:
        xpde.append(float(row["xpde"]))
        pspde.append(float(row["pspde"]))
        ypde.append(float(row["ypde"]))


xx=np.array(x)
pps=np.array(ps)
yy=np.array(y)
yy1=np.array(x1)
yy2=np.array(x2)


xxpde=np.array(xpde)
ppspde=np.array(pspde)
yypde=np.array(ypde)

fig=plt.figure()
ax= fig.gca(projection='3d')
ax.scatter(xxpde, ppspde, yypde, c='y')

ax.scatter(xx, pps, yy, label='Courbe', marker='d')
#ax.scatter(xx, pps, yy1, label='Courbe',c='y')
#ax.scatter(xx, pps, yy2, label='Courbe',c='g')

plt.title("Facture en fonction de la capacité et de la surface de panneaux solaires")
ax.set_xlabel('capacité')
ax.set_ylabel('surface de panneaux solaires')
ax.set_zlabel('facture')
plt.tight_layout()
plt.show()

#plt.plot(x,y)
#plt.plot(x,x1)
#plt.plot(x,x2)
#plt.title("facture en fonction de la capacité")
#plt.legend()
#plt.show()

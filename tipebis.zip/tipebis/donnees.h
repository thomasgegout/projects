#include<stdio.h> 
#include<stdbool.h> 
#include<stdlib.h> 
#include<string.h>

#include "simplexe.h"

struct tabdonnees {
	float* subdiv;
	float* dem;
	float* prod;
	float* pres_min;
	float* pres_max;
	float* c;
	float* cp;
};

typedef struct tabdonnees *tab_tab;

void libere_tab (tab_tab remp);

void recup_tab (tab_tab remplir,char* name);

void grandit_tab (tab_tab remp, int j);

tab_tab combine_tab (tab_tab aut,tab_tab hiv,tab_tab prin,tab_tab ete,int nb_j);

float calc_fact(int h,res_tab resultats,float* c,float* cp);

void extract_var (res_tab var,float* tab,char* name,float* subdiv);

float fact_an (res_tab var,float* pria,float* priv,int jours,int long_saison);

res_tab glouton_stockless (int nb_h,float* d,float* p,float* c,float* cp,
				float*pres_min,float* pres_max);

res_tab glouton (int nb_h,float* d,float* p,float* c,float* cp,float*pres_min,
				float* pres_max,float Enom,float SOCstart,
				float SOCmin,float SOCmax,float SOCend);
